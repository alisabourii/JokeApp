﻿namespace JokeWebApp.Models
{
    public class Joke
    {
        public int Id { get; set; }
        public string JokeQues { get; set; }
        public string JokeAnswer { get; set; }
    }
}
