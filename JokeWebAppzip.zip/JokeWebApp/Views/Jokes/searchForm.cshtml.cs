using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace JokeWebApp.Views.Jokes
{
    public class searchFormModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
